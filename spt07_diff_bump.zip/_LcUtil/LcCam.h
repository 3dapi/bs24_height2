// Interface for the CLcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _LcCam_H_
#define _LcCam_H_

class CLcCam
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;

	FLOAT				m_fScnW;												// screen width
	FLOAT				m_fScnH;												// screen height
	FLOAT				m_fFov;													// Field of View
    FLOAT				m_fAs;													// Aspect Ratio
    FLOAT				m_fNr;													// Near
    FLOAT				m_fFr;													// Far

	VEC3				m_vcEye;												// Camera position
	VEC3				m_vcLook;												// Look vector
	VEC3				m_vcUp;													// up vector

	FLOAT				m_fYaw;
	FLOAT				m_fPitch;

	MATA				m_mtViw;												// View Matrix
	MATA				m_mtPrj;												// Projection Matrix

	MATA				m_mtViwI;												// View Matrix Inverse
	MATA				m_mtBill;												// BillBoard Matrix
	MATA				m_mtVwPj;												// m_mtViw * m_mtPrj;

	D3DXPLANE			m_Frsm[6];												// Near, Far, Left, Right, Up, Down

public:
	CLcCam();
	virtual ~CLcCam();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	INT		FrameMove();

	const MATA*	const GetMatrixViw()   const {	return &m_mtViw;	}
	const MATA*	const GetMatrixViwI()  const {	return &m_mtViwI;	}
	const MATA*	const GetMatrixBll()   const {	return &m_mtBill;	}
	const MATA*	const GetMatrixPrj()   const {	return &m_mtPrj;	}
	const MATA*	const GetMatrixViwPrj()const {	return &m_mtVwPj;	}

	const VEC3*	const GetEye()         const {	return &m_vcEye;	}
	const VEC3*	const GetLook()        const {	return &m_vcLook;	}
	const VEC3*	const GetUp()          const {	return &m_vcUp;		}

public:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	void	Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed);
};

#endif
