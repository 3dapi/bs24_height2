// Implementation of the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcSplt.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


INT m_IdxLA[][33] =	 					// Texture Index
{
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},

	{0,0,0,1,1,1,1,1,	3,3,3,3,3,3,3,3,	0,1,1,2,0,0,2,1,	2,3,3,2,0,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	3,3,3,3,3,3,3,3,	0,1,1,2,2,3,0,1,	2,1,1,2,0,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	3,3,3,2,3,3,3,1,	0,0,1,3,3,1,1,1,	1,1,1,2,0,1,1,1,1,	},
	{0,0,0,1,1,1,3,3,	3,3,3,3,3,2,2,0,	0,1,1,1,3,1,1,1,	2,2,2,1,0,1,1,1,1,	},

	{0,0,0,1,1,1,3,3,	3,3,3,3,2,2,2,0,	0,1,1,1,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},
	{0,0,0,3,3,3,3,3,	3,3,2,2,2,2,2,0,	0,2,2,2,3,1,2,2,	2,2,2,2,1,2,2,2,2,	},
	{0,0,0,3,3,3,3,3,	3,3,2,2,2,2,0,0,	0,1,2,0,2,2,2,1,	1,1,2,2,2,1,1,1,1,	},
	{0,0,0,3,3,3,3,3,	3,3,2,2,2,2,2,0,	0,0,2,2,0,2,2,0,	2,0,2,2,1,1,1,1,1,	},

	{0,0,0,3,3,3,3,3,	2,2,2,2,2,2,2,1,	0,0,1,2,0,0,2,1,	2,1,1,2,3,1,1,1,1,	},
	{0,0,0,3,3,3,3,3,	2,2,2,2,2,2,2,0,	0,0,1,2,0,0,0,1,	2,1,3,3,3,1,1,1,1,	},
	{0,0,0,1,1,1,2,2,	2,2,2,2,2,2,1,0,	0,0,1,2,0,1,3,3,	1,0,1,2,1,1,1,1,1,	},
	{0,0,0,1,1,1,2,2,	2,2,2,2,2,1,1,0,	0,0,2,1,0,1,3,3,	2,2,2,1,1,1,1,1,1,	},

	{0,0,0,1,1,1,1,1,	2,2,2,2,2,1,1,0,	0,0,1,3,3,1,1,1,	3,1,3,3,1,2,2,2,2,	},
	{0,0,0,2,2,2,2,2,	2,2,2,2,2,2,2,0,	0,0,2,2,2,2,2,2,	2,2,2,2,2,2,2,2,2,	},
	{0,0,0,2,2,2,2,0,	0,2,2,3,2,2,2,1,	0,0,0,0,2,2,2,1,	1,3,2,3,2,1,1,1,1,	},
	{0,0,0,2,2,2,2,0,	0,3,3,3,3,2,2,0,	2,0,0,2,0,2,2,2,	2,3,3,3,2,1,1,1,1,	},

	{0,0,0,2,2,0,2,0,	0,3,3,3,3,0,0,0,	0,0,1,2,0,0,2,2,	2,3,3,2,2,1,1,1,1,	},
	{0,0,0,2,2,0,0,0,	1,1,1,3,3,0,0,0,	0,0,0,2,2,2,2,2,	2,1,1,2,2,1,1,1,1,	},
	{0,0,0,0,0,0,0,0,	0,0,1,3,3,3,3,0,	0,0,0,3,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},
	{0,0,0,2,2,0,0,0,	0,1,1,1,1,1,1,0,	0,0,0,1,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},

	{0,0,0,2,2,0,0,0,	0,1,1,1,1,1,1,0,	0,0,0,1,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},
	{0,0,0,2,2,2,2,0,	0,2,2,2,2,1,1,0,	0,0,2,2,3,1,2,2,	2,2,2,2,1,1,1,1,1,	},
	{0,0,0,2,2,2,2,0,	0,2,2,2,2,1,1,0,	0,0,2,0,0,2,2,1,	1,1,2,1,1,1,1,1,1,	},
	{0,0,0,0,0,2,2,0,	0,2,2,2,2,2,2,0,	0,0,2,0,0,2,2,1,	2,1,2,2,1,1,1,1,1,	},

	{0,0,0,0,0,0,0,1,	1,1,1,1,1,2,2,0,	0,1,1,0,0,0,2,1,	2,1,2,2,2,1,1,1,1,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
};



CLcSplt::CLcSplt()
{
	m_pDev	= NULL;
	m_nVtx	= 0;
	m_pFce	= 0;

	m_pFce	= NULL;
	m_pVtx	= NULL;

	m_iTile	= 0;
	m_fWidth= 0;

	m_nTex	= 0;
	m_pTex	= NULL;
}


CLcSplt::~CLcSplt()
{
	Destroy();
}



char* sTsLst[] =
{
	"Base_03.png",
	"Base_03_n.png",
	"Base_01.tga",
	"Base_01_n.tga",
	"Base_02.tga",
	"Base_02_n.tga",
	"Base_04.tga",
	"Base_04_n.tga",
};


INT CLcSplt::Create(PDEV pDev)
{
	m_pDev	= pDev;

	int i, j, n, m;

	int	nTile	= 32;

	m_iTile		= nTile + 1;		// nTile in x, z
	m_fWidth	= 32;				// Width
	m_nTex		= 4;				// Number of Texture Layer

	m_nVtx = m_iTile * m_iTile;
	m_nFce =  nTile * nTile * 2;

	m_pVtx = new VtxDUV1[m_nVtx];
	m_pFce = new VtxIdx [m_nFce];


	i=0;
	for(m=0; m< nTile/2;++m)
	{
		for(n=0;n<nTile/2;++n)
		{
			WORD s;
			WORD d;
			WORD a;

			WORD f[9];

			s = nTile + 2;

			d=  (nTile+ 1)*2;

			a = m * d + n * 2 + s;

			f[1] = a +nTile+0;	f[2] = a + nTile+1;	f[3] = a +nTile+2;
			f[8] = a - 1;		f[0] = a;			f[4] = a + 1;
			f[7] = a -nTile-2;	f[6] = a - nTile-1;	f[5] = a -nTile-0;

			m_pFce[i+0] = VtxIdx(f[0], f[1], f[2]);
			m_pFce[i+1] = VtxIdx(f[0], f[2], f[3]);
			m_pFce[i+2] = VtxIdx(f[0], f[3], f[4]);
			m_pFce[i+3] = VtxIdx(f[0], f[4], f[5]);
			m_pFce[i+4] = VtxIdx(f[0], f[5], f[6]);
			m_pFce[i+5] = VtxIdx(f[0], f[6], f[7]);
			m_pFce[i+6] = VtxIdx(f[0], f[7], f[8]);
			m_pFce[i+7] = VtxIdx(f[0], f[8], f[1]);

			i +=8;
		}
	}

	for(j=0; j<m_iTile; ++j)
	{
		for(i=0; i<m_iTile; ++i)
		{
			m_pVtx[j*m_iTile+i] = VtxDUV1(i * m_fWidth, 0, j * m_fWidth, i/5.f, j/5.f);
		}
	}


	m_pTex = new TexWgt[m_nTex];												//Base Tile Texture ����

	for (i = 0; i < m_nTex; ++i)
	{
		char	sFile[MAX_PATH]={0};
		sprintf(sFile, "Texture/%s", sTsLst[2*i + 0]);
		TextureLoad(sFile, m_pTex[i].pTexB);

		sprintf(sFile, "Texture/%s", sTsLst[2*i + 1]);
		TextureLoad(sFile, m_pTex[i].pTexN);

		m_pTex[i].pTwgt	= (DWORD*)malloc(m_nVtx * sizeof(DWORD));
		memset(m_pTex[i].pTwgt, 0xFF, m_nVtx * sizeof(DWORD));
	}


	CalculateMap();


	m_vcLgt = VEC3(1.0f,1.0f,1.0f);
	VectorToRGB();

	return 0;
}

void CLcSplt::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pFce	);
	SAFE_DELETE_ARRAY(	m_pVtx	);

	SAFE_DELETE_ARRAY(	m_pTex	);
}




INT CLcSplt::FrameMove()
{
	return 0;
}


void CLcSplt::Render()
{
	int	i;

	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE,    FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE,   TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetRenderState(D3DRS_TEXTUREFACTOR, m_dTFt);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1,   D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2,   D3DTA_TFACTOR);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP  ,   D3DTOP_DOTPRODUCT3);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP  ,   D3DTOP_DISABLE);

	m_pDev->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX,   0);
	m_pDev->SetTextureStageState(1, D3DTSS_COLORARG1,   D3DTA_CURRENT);
	m_pDev->SetTextureStageState(1, D3DTSS_COLORARG2,   D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(1, D3DTSS_COLOROP  ,   D3DTOP_MODULATE2X);

	m_pDev->SetTextureStageState(1, D3DTSS_ALPHAARG1,   D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(1, D3DTSS_ALPHAOP  ,   D3DTOP_SELECTARG1);

	for(i=0; i<3; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU , D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV , D3DTADDRESS_WRAP);
	}

	m_pDev->SetFVF(VtxDUV1::FVF);

	for(i=0; i<m_nTex; ++i)
	{
		m_pDev->SetTexture(0, m_pTex[i].pTexN);
		m_pDev->SetTexture(1, m_pTex[i].pTexB);

		for(int m=0; m<m_iTile; ++m)
		{
			for(int n=0; n<m_iTile; ++n)
			{
				m_pVtx[m*m_iTile+n].d = m_pTex[i].pTwgt[m*m_iTile+n];
			}
		}

		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST   //  PrimitiveType
										, 0                 //  Min Vertex Index
										, m_nVtx            //  Num Vertices
										, m_nFce            //  Primitive Count
										, m_pFce            //  pIndex Data
										, D3DFMT_INDEX16    //  Index Data Format
										, m_pVtx            //  pVertex Stream Zero Data
										, sizeof(VtxDUV1)   //  Vertex Stream Zero Stride
										);
	}

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);


	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);

	m_pDev->SetTextureStageState(1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE);
	m_pDev->SetTextureStageState(1, D3DTSS_COLOROP,   D3DTOP_DISABLE);
}





////////////////////////////////////////////////////////////////////////////////
VEC3& CLcSplt::GetLightDir()
{
	return m_vcLgt;
}


void CLcSplt::CalculateMap()
{
	INT i;

	for(i=0; i<m_nTex; ++i)
	{
		CalculateMapTile(i, m_pTex[i].pTwgt);
	}
}

void CLcSplt::CalculateMapTile(int nTx, DWORD* &xpTxA)
{
	INT		x, z, m, n;
	INT		nXBgn, nXEnd;
	INT		nZBgn, nZEnd;

	FLOAT	fAlpha;
	FLOAT	fN;

	for (z=0; z<m_iTile; ++z)
	{
		for (x=0; x<m_iTile; ++x)
		{
			fAlpha = 0.0f;

			if(z==0)
			{
				if(x==0)
				{
					nXBgn	= 0;	nXEnd	= 1;
					nZBgn	= 0;	nZEnd	= 1;
				}

				else if(x==(m_iTile-1))
				{
					nXBgn	= -1;	nXEnd	= 0;
					nZBgn	= 0;	nZEnd	= 1;
				}

				else
				{
					nXBgn	= -1;	nXEnd	= 1;
					nZBgn	= 0;	nZEnd	= 1;
				}
			}

			else if(z==(m_iTile-1))
			{
				if(x==0)
				{
					nXBgn	= 0;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 0;
				}

				else if(x==(m_iTile-1))
				{
					nXBgn	= -1;	nXEnd	= 0;
					nZBgn	= -1;	nZEnd	= 0;
				}

				else
				{
					nXBgn	= -1;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 0;
				}
			}

			else
			{
				if(x==0)
				{
					nXBgn	= 0;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 1;
				}

				else if(x==(m_iTile-1))
				{
					nXBgn	= -1;	nXEnd	= 0;
					nZBgn	= -1;	nZEnd	= 1;
				}

				else
				{
					nXBgn	= -1;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 1;
				}
			}

			for(m=nZBgn; m<=nZEnd; ++m)
			{
				for(n=nXBgn; n<=nXEnd; ++n)
				{
					if(m_IdxLA[z+m][x+n] ==nTx)
						fAlpha +=1.f;
				}
			}

			fN = abs( (nXEnd-nXBgn) * (nZEnd-nZBgn) );

			fAlpha *=2.0f;
			fAlpha /= fN;

			if(fAlpha>1.f)
				fAlpha = 1.f;



			xpTxA[m_iTile*z + x] = D3DXCOLOR(1,1,1, fAlpha);
		}// for
	}// for
}


INT CLcSplt::TextureLoad(char* sFileName
						, PDTX& texture
						, DWORD _color
						, D3DXIMAGE_INFO*pSrcInfo
						, DWORD Filter
						, DWORD MipFilter
						, D3DFORMAT d3dFormat)
{
	if (FAILED(D3DXCreateTextureFromFileEx(
		m_pDev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)))
	{
		texture = NULL;
		return -1;
	}

	return 0;
}



void CLcSplt::VectorToRGB()
{
	D3DXVec3Normalize(&m_vcLgt, &m_vcLgt);

	DWORD dwR = (DWORD)(100.f * m_vcLgt.x + 155.f);
	DWORD dwG = (DWORD)(100.f * m_vcLgt.y + 155.f);
	DWORD dwB = (DWORD)(100.f * m_vcLgt.z + 155.f);

	m_dTFt = (DWORD)(0xff000000 + (dwR << 16) + (dwG << 8) + dwB);
}