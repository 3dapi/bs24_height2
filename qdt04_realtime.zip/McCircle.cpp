// Implementation of the CMcCircle class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4244)


#include "_StdAfx.h"


extern INT			g_iLvlW;
extern D3DXVECTOR3	g_pPos;


CMcCircle::CMcCircle()
{
	m_pRad	= NULL;
}

CMcCircle::~CMcCircle()
{
	Destroy();
}


INT CMcCircle::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	INT i=0;

	m_pRad = (VtxD**) malloc( 10 * sizeof(VtxD*));

	for(i=0;i<7; ++i)
	{
		m_pRad[i] = (VtxD*) malloc( 181 * sizeof(VtxD));
	}

	return 0;
}


void CMcCircle::Destroy()
{
	if(m_pRad)
	{
		for(int i=0;i<7; ++i)
			SAFE_FREE(	m_pRad[i]	);

		SAFE_FREE(m_pRad);
	}
}


INT	CMcCircle::FrameMove()
{
	for(int i=0;i<7; ++i)
	{
		DWORD	d	= D3DXCOLOR(1, 0, 1, 1);

		for(int j=0; j<181; ++j)
		{
			FLOAT	fR = g_iLvlW * i;
			FLOAT	fCos = fR * cosf( D3DXToRadian(j*2)) +g_pPos.x;
			FLOAT	fSin = fR * sinf( D3DXToRadian(j*2)) +g_pPos.z;

			m_pRad[i][j] = VtxD(fCos, 0, fSin, d);
		}
	}



	return 0;
}

void CMcCircle::Render()
{
	// Render Lines
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetFVF(VtxD::FVF);

	for(int i=0;i<7; ++i)
	{
		m_pDev->DrawPrimitiveUP(D3DPT_LINESTRIP, 180, m_pRad[i], sizeof(VtxD));
	}
}
