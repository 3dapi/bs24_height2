// Interface for the CMcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _McCam_H_
#define _McCam_H_

class CMcCam
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;

	FLOAT				m_fScnW;												// screen width
	FLOAT				m_fScnH;												// screen height
	FLOAT				m_fFov;													// Field of View
    FLOAT				m_fAs;													// Aspect Ratio
    FLOAT				m_fNr;													// Near
    FLOAT				m_fFr;													// Far

	D3DXVECTOR3			m_vcEye;												// Camera position
	D3DXVECTOR3			m_vcLook;												// Look vector
	D3DXVECTOR3			m_vcUp;													// up vector

	FLOAT				m_fYaw;													// angle yaw
	FLOAT				m_fPitch;												// angle pitch

	D3DXMATRIX			m_mtViw;												// View Matrix
	D3DXMATRIX			m_mtPrj;												// Projection Matrix

	D3DXMATRIX			m_mtViwI;												// View Matrix Inverse
	D3DXMATRIX			m_mtBill;												// BillBoard Matrix
	D3DXMATRIX			m_mtVwPj;												// m_mtViw * m_mtPrj;

	D3DXPLANE			m_Frsm[6];												// Near, Far, Left, Right, Up, Down

public:
	CMcCam();
	virtual ~CMcCam(){}

	INT			Create(LPDIRECT3DDEVICE9);
	INT			FrameMove();

	const D3DXMATRIX* const GetMatrixViw()   const{	return &m_mtViw;	}
	const D3DXMATRIX* const GetMatrixViwI()  const{	return &m_mtViwI;	}
	const D3DXMATRIX* const GetMatrixBll()   const{	return &m_mtBill;	}
	const D3DXMATRIX* const GetMatrixPrj()   const{	return &m_mtPrj;	}
	const D3DXMATRIX* const GetMatrixViwPrj()const{	return &m_mtVwPj;	}

	const D3DXVECTOR3* const GetCamPos()     const{ return &m_vcEye;	}
	const D3DXVECTOR3* const GetCamLook()    const{ return &m_vcLook;	}
	const D3DXVECTOR3* const GetCamUp()      const{ return &m_vcUp;		}

protected:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
};

#endif
