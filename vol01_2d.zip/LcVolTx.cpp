// Implementation of the CLcVolTx class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning( disable : 4996)

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcVolTx.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcVolTx::CLcVolTx()
{
	m_pDev	= NULL;
	m_pTxv	= NULL;
}

CLcVolTx::~CLcVolTx()
{
	Destroy();
}



INT CLcVolTx::Create(PDEV pDev)
{
	m_pDev = pDev;

	HRESULT		hr;
	D3DXIMAGE_INFO imageinfo2;

	TCHAR sFile[] = "Texture/mario.dds";

	hr = D3DXGetImageInfoFromFile( sFile, &m_pImg );

	if(FAILED(hr))
        return -1;

	// Create a volume texture
	hr = D3DXCreateVolumeTextureFromFileEx( m_pDev, sFile,
			m_pImg.Width, m_pImg.Height, m_pImg.Depth, m_pImg.MipLevels
			, 0, m_pImg.Format, D3DPOOL_MANAGED
			, D3DX_FILTER_NONE, D3DX_FILTER_NONE
			, 0, &imageinfo2, NULL, &m_pTxv );

	if(FAILED(hr))
        return -1;


	FLOAT d= m_pImg.Depth * 1.f;
	FLOAT w= .5f;

	w /= d;

	m_pVtx[0] = VtxRHWDUVW(100,  50, 0,   0, 0,  w);
	m_pVtx[1] = VtxRHWDUVW(400,  50, 0,   1, 0,  w);
	m_pVtx[2] = VtxRHWDUVW(400, 550, 0,   1, 1,  w);
	m_pVtx[3] = VtxRHWDUVW(100, 550, 0,   0, 1,  w);

	return 0;
}

void CLcVolTx::Destroy()
{
	SAFE_RELEASE(	m_pTxv	);
}




INT CLcVolTx::FrameMove()
{
	FLOAT d= m_pImg.Depth * 1.f;

	static FLOAT w= .5f;

	static DWORD dBgn = timeGetTime();

	DWORD dEnd = timeGetTime();

	if(dEnd> dBgn+100)
	{
		dBgn = dEnd;

		w+=1.f;

		if(w>7.f)
			w= .5f;

		float d2 = w/d;

		m_pVtx[0].w = d2;
		m_pVtx[1].w = d2;
		m_pVtx[2].w = d2;
		m_pVtx[3].w = d2;
	}

	return 0;
}


void CLcVolTx::Render()
{
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	m_pDev->SetTexture( 0, m_pTxv );

	m_pDev->SetFVF(VtxRHWDUVW::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxRHWDUVW));

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetTexture( 0, NULL);
}
