// Interface for the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcSplt_H_
#define _LcSplt_H_


typedef D3DXVECTOR3							VEC3;
typedef D3DXMATRIX							MATA;
typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPDIRECT3DTEXTURE9					PDTX;
typedef	D3DXIMAGE_INFO						DIMG;


class CLcSplt
{
public:
	struct VtxRHWDUV1
	{
		D3DXVECTOR4	p;
		DWORD		d;
		FLOAT		u, v;

		VtxRHWDUV1(){}
		VtxRHWDUV1(FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT U, FLOAT V, DWORD D=0xFFFFFFFF)
				: p(X,Y,Z, 1.0F), u(U), v(V), d(D){}

		enum {	FVF= (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)	};
	};


protected:
	PDEV		m_pDev;
	
	VtxRHWDUV1	m_pVtx[4];														// Vertex Layer
	PDTX		m_pTxB[2];														// Base Texture
	PDTX		m_pTxA[2];														// Alpha Texture

	BOOL		m_bFilter;

public:
	CLcSplt();
	virtual ~CLcSplt();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	SetTextureFilter();

protected:
	INT		TextureLoad(char* sFileName
						, PDTX& texture
						, DWORD _color=0x00FFFFFF
						, D3DXIMAGE_INFO *pSrcInfo=NULL
						, DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, D3DFORMAT d3dFormat = D3DFMT_UNKNOWN);
};

#endif
