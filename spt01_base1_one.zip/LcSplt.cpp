// Implementation of the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcSplt.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcSplt::CLcSplt()
{
	m_pDev	= NULL;

	m_pTxB[0] = NULL;
	m_pTxB[1] = NULL;

	m_pTxA[0] = NULL;
	m_pTxA[1] = NULL;

	m_bFilter	= 1;
}

CLcSplt::~CLcSplt()
{
	Destroy();
}



INT CLcSplt::Create(PDEV pDev)
{
	m_pDev	= pDev;


	for(int i=0; i<2; ++i)
	{
		char	sFile[MAX_PATH]={0};
		sprintf(sFile, "Texture/Base_0%d.png", i+1);
		TextureLoad(sFile, m_pTxB[i]);

		sprintf(sFile, "Texture/Alpha_0%d.png", i+1, i+1);
		TextureLoad(sFile, m_pTxA[i], 0x00FFFFFF);
	}

	m_pVtx[0] = VtxRHWDUV1( 20,  20, 0,	0.0F, 0.0F,	 0xFFFFFF00);
	m_pVtx[1] = VtxRHWDUV1(780,  20, 0,	1.0F, 0.0F,	 0xFF00FF55);
	m_pVtx[2] = VtxRHWDUV1(780, 580, 0,	1.0F, 1.0F,	 0xFF0000FF);
	m_pVtx[3] = VtxRHWDUV1( 20, 580, 0,	0.0F, 1.0F,	 0xFFFF00FF);

	m_pVtx[0] = VtxRHWDUV1( 20,  20, 0,	0.0F, 0.0F,	 0xFFFFFFFF);
	m_pVtx[1] = VtxRHWDUV1(780,  20, 0,	1.0F, 0.0F,	 0xFFFFFFFF);
	m_pVtx[2] = VtxRHWDUV1(780, 580, 0,	1.0F, 1.0F,	 0xFFFFFFFF);
	m_pVtx[3] = VtxRHWDUV1( 20, 580, 0,	0.0F, 1.0F,	 0xFFFFFFFF);

	return 0;
}

void CLcSplt::Destroy()
{
	for(int i=0; i<2; ++i)
	{
		SAFE_RELEASE(	m_pTxB[i]	);
		SAFE_RELEASE(	m_pTxA[i]	);
	}
}




INT CLcSplt::FrameMove()
{
	return 0;
}


void CLcSplt::Render()
{
	int	i;

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP,   D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(1, D3DTSS_COLORARG1, D3DTA_CURRENT);
	m_pDev->SetTextureStageState(1, D3DTSS_COLORARG2, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(1, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(1, D3DTSS_RESULTARG, D3DTA_TEMP);

	m_pDev->SetTextureStageState(2, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(2, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(2, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(2, D3DTSS_RESULTARG, D3DTA_CURRENT);

	m_pDev->SetTextureStageState(3, D3DTSS_COLORARG1, D3DTA_CURRENT);
	m_pDev->SetTextureStageState(3, D3DTSS_COLORARG2, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(3, D3DTSS_COLOROP,   D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(4, D3DTSS_COLORARG1, D3DTA_CURRENT);
	m_pDev->SetTextureStageState(4, D3DTSS_COLORARG2, D3DTA_TEMP);
	m_pDev->SetTextureStageState(4, D3DTSS_COLOROP,   D3DTOP_ADD);


	for(i=0; i<6; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

		m_pDev->SetTextureStageState(1+i, D3DTSS_TEXCOORDINDEX, 0);
	}

	if(!m_bFilter)
	{
		m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_NONE);
		m_pDev->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	}



	m_pDev->SetFVF(VtxRHWDUV1::FVF);

	m_pDev->SetTexture(0, m_pTxB[0]);	// ��ǻ�� �ؽ�ó0
	m_pDev->SetTexture(1, m_pTxA[0]);	// ���� �ؽ�ó0

	m_pDev->SetTexture(2, m_pTxB[1]);	// ��ǻ�� �ؽ�ó1
	m_pDev->SetTexture(3, m_pTxA[1]);	// ���� �ؽ�ó1

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxRHWDUV1));



	for(i=0; i<4; ++i)
	{
		m_pDev->SetTexture(i, NULL);
	}

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE);
	m_pDev->SetTextureStageState(1, D3DTSS_COLOROP,   D3DTOP_DISABLE);
}





////////////////////////////////////////////////////////////////////////////////

void CLcSplt::SetTextureFilter()
{
	m_bFilter ^=1;
}




INT CLcSplt::TextureLoad(char* sFileName
						, PDTX& texture
						, DWORD _color
						, D3DXIMAGE_INFO*pSrcInfo
						, DWORD Filter
						, DWORD MipFilter
						, D3DFORMAT d3dFormat)
{
	if (FAILED(D3DXCreateTextureFromFileEx(
		m_pDev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)))
	{
		texture = NULL;
		return -1;
	}

	return 0;
}
