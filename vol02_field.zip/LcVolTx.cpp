// Implementation of the CLcVolTx class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning( disable : 4996)

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcVolTx.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcVolTx::CLcVolTx()
{
	m_pDev	= NULL;
	m_pVB	= NULL;
	m_pIB	= NULL;
	m_pTxv	= NULL;
}

CLcVolTx::~CLcVolTx()
{
	Destroy();
}



INT CLcVolTx::Create(PDEV pDev)
{
	m_pDev = pDev;

	INT			i, j;
	HRESULT		hr;
	D3DXIMAGE_INFO imageinfo;
    D3DXIMAGE_INFO imageinfo2;

	TCHAR sFile[] = "Texture/map.dds";

	hr = D3DXGetImageInfoFromFile( sFile, &imageinfo );
    if(FAILED(hr))
        return -1;

	// Create a volume texture
	hr = D3DXCreateVolumeTextureFromFileEx( m_pDev, sFile,
            imageinfo.Width, imageinfo.Height, imageinfo.Depth, D3DX_DEFAULT,
            0, imageinfo.Format, D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE, D3DX_FILTER_TRIANGLE,
            0x00ffffff, &imageinfo2, NULL, &m_pTxv );

	if(FAILED(hr))
        return -1;


	m_iNvx = 33 * 33;
	m_iNix = 32 * 32 * 2;

	// Create Vertex Buffer
	VtxDUVW	*pVB;
	m_pDev->CreateVertexBuffer(m_iNvx * sizeof(VtxDUVW), 0, VtxDUVW::FVF, D3DPOOL_MANAGED, &m_pVB, NULL);



	m_pVB->Lock(0, 0, (void**)&pVB, 0);
	for (j = 0; j < 33; j++)
	{
		for (i = 0; i < 33; i++)
		{
			int idx = j * 33 + i;
			pVB[idx].p = D3DXVECTOR3(i * 32-512.f, 0.f, j * 32-512.f);
			pVB[idx].d = 0xFFFFFFFF;

			pVB[idx].u = i / 8.f;
			pVB[idx].v = j / 8.f;


			FLOAT h = 360.f/sqrtf( 0.05f * (( i-16) * (i-16) + ( j-16) * (j-16)) +1.f);
			FLOAT w = 2.5f+sinf( D3DXToRadian (rand()%360));

			w= h/300.f * imageinfo.Depth +0.5f;
			pVB[idx].w = w/imageinfo.Depth;
			pVB[idx].p.y = h;

//			if(i<8)
//				pVB[idx].w = .5f/imageinfo.Depth;//
//			else if( i<16)
//				pVB[idx].w = 1.5f/imageinfo.Depth;
//
//			else if( i<24)
//				pVB[idx].w = 2.5f/imageinfo.Depth;
//
//			else
//				pVB[idx].w = 3.5f/imageinfo.Depth;		//			(i/16) +1    32.f) ;/// imageinfo.Depth;//FLOAT(2+rand()%(imageinfo.Depth -2) - 0.5f) / imageinfo.Depth;
//
//			if(i ==16 && j==16)
//				pVB[idx].w = 2.5f/imageinfo.Depth;
		}
	}
	m_pVB->Unlock();



	// Create Index Buffer
	WORD		*pIB;
	m_pDev->CreateIndexBuffer(m_iNix * 3 * sizeof(WORD), 0, D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pIB, 0);

	m_pIB->Lock(0, 0, (void**)&pIB, 0);
	for (i = 0; i < 32; i++)
	{
		for (j = 0; j < 32; j++)
		{

			int idx = i * 32 + j;

			pIB[idx * 6 + 0] = i * 33 + j;
			pIB[idx * 6 + 1] = (i + 1) * 33 + j;
			pIB[idx * 6 + 2] = (i + 1) * 33 + j + 1;

			pIB[idx * 6 + 3] = pIB[idx * 6 + 2];
			pIB[idx * 6 + 4] = i * 33 + j + 1;
			pIB[idx * 6 + 5] = pIB[idx * 6 + 0];
		}
	}

	m_pIB->Unlock();

	return 0;
}

void CLcVolTx::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
	SAFE_RELEASE(	m_pIB	);
	SAFE_RELEASE(	m_pTxv	);
}




INT CLcVolTx::FrameMove()
{
	return 0;
}


void CLcVolTx::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);

	m_pDev->SetTexture( 0, m_pTxv );

	m_pDev->SetFVF(VtxDUVW::FVF);
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(VtxDUVW));
	m_pDev->SetIndices(m_pIB);
	m_pDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_iNvx, 0, m_iNix);

	m_pDev->SetTexture( 0, NULL);
}
