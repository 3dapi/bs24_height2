// Interface for the CLcVolTx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcVolTx_H_
#define _LcVolTx_H_


typedef D3DXVECTOR3							VEC3;

typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPDIRECT3DTEXTURE9					PDTX;


class CLcVolTx
{
public:
	struct VtxDUVW
	{
		D3DXVECTOR3	p;
		DWORD	d;
		FLOAT	u, v, w;
		VtxDUVW()	{}
		VtxDUVW(D3DXVECTOR3 P,FLOAT U,FLOAT V
			,FLOAT W,DWORD D=0xFFFFFFFF) : p(P), u(U),v(V),w(W),d(D){}

		VtxDUVW(FLOAT X,FLOAT Y,FLOAT Z
			,FLOAT U,FLOAT V,FLOAT W
			,DWORD D=0xFFFFFFFF): p(X,Y,Z), u(U),v(V),d(D){}

		enum	{FVF = (D3DFVF_XYZ | D3DFVF_DIFFUSE \
						| D3DFVF_TEX1 | D3DFVF_TEXCOORDSIZE3(0) ),};

	};


protected:
	LPDIRECT3DDEVICE9			m_pDev;

	INT							m_iNvx;	// number of vertex
	INT							m_iNix;	// number of index
	LPDIRECT3DVERTEXBUFFER9		m_pVB;	// vertex buffer
	LPDIRECT3DINDEXBUFFER9		m_pIB;	// index buffer
	LPDIRECT3DVOLUMETEXTURE9	m_pTxv;	// volume texture



public:
	CLcVolTx();
	virtual ~CLcVolTx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
