// Implementation of the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcSplt.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcSplt::CLcSplt()
{
	m_pDev	= NULL;

	m_pTxB[0] = NULL;
	m_pTxB[1] = NULL;
}

CLcSplt::~CLcSplt()
{
	Destroy();
}



INT CLcSplt::Create(PDEV pDev)
{
	m_pDev	= pDev;


	m_nTex	= 2;

	for(int i=0; i<m_nTex; ++i)
	{
		char	sFile[MAX_PATH]={0};
		sprintf(sFile, "Texture/Base_0%d.png", i+1);
		TextureLoad(sFile, m_pTxB[i]);
	}

	m_pVtx[0][0] = VtxDUV1(   0, 0, 1024,  0.0F, 0.0F,  0xFFFFFFFF);
	m_pVtx[0][1] = VtxDUV1(1024, 0, 1024,  1.0F, 0.0F,  0x00FFFFFF);
	m_pVtx[0][2] = VtxDUV1(1024, 0,    0,  1.0F, 1.0F,  0x00FFFFFF);
	m_pVtx[0][3] = VtxDUV1(   0, 0,    0,  0.0F, 1.0F,  0xFFFFFFFF);

	m_pVtx[1][0] = VtxDUV1(   0, 0, 1024,  0.0F, 0.0F,  0x00FFFFFF);
	m_pVtx[1][1] = VtxDUV1(1024, 0, 1024,  1.0F, 0.0F,  0xFFFFFFFF);
	m_pVtx[1][2] = VtxDUV1(1024, 0,    0,  1.0F, 1.0F,  0xFFFFFFFF);
	m_pVtx[1][3] = VtxDUV1(   0, 0,    0,  0.0F, 1.0F,  0x00FFFFFF);

	return 0;
}

void CLcSplt::Destroy()
{
	for(int i=0; i<m_nTex; ++i)
	{
		SAFE_RELEASE(	m_pTxB[i]	);
	}
}




INT CLcSplt::FrameMove()
{
	return 0;
}


void CLcSplt::Render()
{
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE,    FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE,   TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU , D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV , D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR  );
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR  );
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR  );

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2,  D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP  ,  D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1,  D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2,  D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP  ,  D3DTOP_DISABLE);


	m_pDev->SetFVF(VtxDUV1::FVF);

	for (int i = 0; i < m_nTex; ++i)
	{
		m_pDev->SetTexture(0, m_pTxB[i]);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx[i], sizeof(VtxDUV1));
	}
}





////////////////////////////////////////////////////////////////////////////////


INT CLcSplt::TextureLoad(char* sFileName
						, PDTX& texture
						, DWORD _color
						, D3DXIMAGE_INFO*pSrcInfo
						, DWORD Filter
						, DWORD MipFilter
						, D3DFORMAT d3dFormat)
{
	if (FAILED(D3DXCreateTextureFromFileEx(
		m_pDev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)))
	{
		texture = NULL;
		return -1;
	}

	return 0;
}

