// Interface for the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcSplt_H_
#define _LcSplt_H_


typedef D3DXVECTOR3							VEC3;
typedef D3DXMATRIX							MATA;
typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPDIRECT3DTEXTURE9					PDTX;
typedef	D3DXIMAGE_INFO						DIMG;


class CLcSplt
{
public:
	struct VtxDUV1
	{
		VEC3	p;
		DWORD	d;
		FLOAT	u, v;

		VtxDUV1(){}
		VtxDUV1(FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT U, FLOAT V, DWORD D=0xFFFFFFFF)
				: p(X,Y,Z), u(U), v(V), d(D){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)	};
	};


protected:
	PDEV		m_pDev;
	
	VtxDUV1		m_pVtx[2][4];													// Vertex Layer
	PDTX		m_pTxB[2];														// Base Texture
	INT			m_nTex;

public:
	CLcSplt();
	virtual ~CLcSplt();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

protected:
	INT		TextureLoad(char* sFileName
						, PDTX& texture
						, DWORD _color=0x00FFFFFF
						, D3DXIMAGE_INFO *pSrcInfo=NULL
						, DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, D3DFORMAT d3dFormat = D3DFMT_UNKNOWN);
};

#endif
