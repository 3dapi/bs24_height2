// Interface for the CQuad class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCQUAD_H_
#define _MCQUAD_H_

class CMcQuad
{
public:
	class CQuad
	{
	public:
		union
		{
			struct
			{
				// ���
				// ���
				CQuad*	m_pRH;
				// ���
				// ���
				CQuad*	m_pLH;
				// ���
				// ���
				CQuad*	m_pLT;
				// ���
				// ���
				CQuad*	m_pRT;

				// Parent
				CQuad*	m_pP;
			};

			CQuad*	pQ[5];
		};

	protected:
		INT					m_iDph;			// Min Level
		INT					m_iLvl;
		bool				m_bEnd;			// Terminated
		INT					m_iTri;			// Triangle Count
		D3DXVECTOR3			m_vcP;			// Position
		INT					m_iBrd;			// breadth

		VtxDUV1				m_pVx[8];
		CMcQuad*			m_pQuad;

	public:
		CQuad();
		~CQuad();

		INT		Create(void* pQuad);
		void	Destroy();

		INT		FrameMove();
		void	Render();

		void	Build(CQuad* _pPrn, INT iDepth, INT iX,INT iZ);
		void	BuildMesh(void* pQuad);

	protected:
		INT		GetDepth(INT iValue);
	};


protected:
	LPDIRECT3DDEVICE9	m_pDev		;
	BYTE*				m_pHi		;
	CQuad*				m_pQ		;

	LPDIRECT3DTEXTURE9	m_pTxmap	;

public:
	CMcQuad();
	virtual ~CMcQuad();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

public:
	void	SetVtx(VtxDUV1& Vtx);
	LPDIRECT3DTEXTURE9	GetTexture();
	void*	GetDevice()						{	return m_pDev;	}
};

#endif