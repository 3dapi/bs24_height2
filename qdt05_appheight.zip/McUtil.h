#ifndef _MCUTIL_H_
#define _MCUTIL_H_

// Macro Ȱ��
// �������̽����� �����ϴٸ� ������ ���� ��ũ�ε��� ������ ���̴�.
// (E) 2004-12-20 Editor: AFEW

#define SAFE_NEWCREATE1(p, CLASSTYPE, v1)										\
{																				\
	if(NULL == (p))																\
	{																			\
		p = new CLASSTYPE;														\
																				\
		if(!(p))																\
		{																		\
			return -1;															\
		}																		\
																				\
		if(FAILED((p)->Create(v1)))												\
		{																		\
			delete p;															\
			p = NULL;															\
			return -1;															\
		}																		\
	}																			\
}


#define SAFE_RESTORE(p)															\
{																				\
	if(p)																		\
	{																			\
		if(FAILED((p)->Restore()))												\
			return -1;															\
	}																			\
}



#define SAFE_FRAMEMOVE(p)														\
{																				\
	if(p)																		\
	{																			\
		if(FAILED(	(p)->FrameMove()))											\
			return -1;															\
	}																			\
}

#define SAFE_FREE(p)		{	if(p)	free(p); p = NULL;		}
#define SAFE_DESTROY(p)		{	if(p)	(p)->Destroy();			}
#define SAFE_INVALIDATE(p)	{	if(p)	(p)->Invalidate();		}
#define SAFE_RENDER(p)		{	if(p)	(p)->Render();			}



// Access variable-argument lists �̿��� MessageBox ��Ÿ ��¹�
// Error MessageBox����
void McUtil_ErrMsgBox(TCHAR *format,...);

//������ Ÿ��Ʋ ���� ����
void McUtil_SetWindowTitle(TCHAR *format,...);



#endif _MCUTIL_H_