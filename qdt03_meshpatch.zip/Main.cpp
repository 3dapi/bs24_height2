// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pCircle		= NULL;
	m_pQuad			= NULL;
}


HRESULT CMain::Init()
{
	D3DXFONT_DESC hFont =
	{
		14, 0, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont) ) )
		return -1;

	SAFE_NEWCREATE1(	m_pInput,	CMcInput, m_pd3dDevice);
	SAFE_NEWCREATE1(	m_pCam,		CMcCam	, m_pd3dDevice);

	SAFE_NEWCREATE1(	m_pCircle,	CMcCircle, m_pd3dDevice);
	SAFE_NEWCREATE1(	m_pQuad,	CMcQuad	, m_pd3dDevice);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pCircle	);

	if(m_pQuad)
		m_pQuad->Destroy();

	SAFE_DELETE(	m_pQuad		);

	return S_OK;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	return S_OK;
}



HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCam		);

	SAFE_FRAMEMOVE(	m_pQuad		);

	return S_OK;
}




HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, D3DXCOLOR(0.9F, 1.0F, 1.0F, 1.0F)
						, 1.0f
						, 0L
						);

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	SAFE_RENDER(	m_pCircle	);

	SAFE_RENDER(	m_pQuad		);

	RenderText();

	m_pd3dDevice->EndScene();

	return S_OK;
}



HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	TCHAR szMsg[MAX_PATH];
	RECT rc;
	rc.left   = 2;
	rc.right  = m_d3dsdBackBuffer.Width - 20;
	rc.top = 3;
	rc.bottom = rc.top + 20;

	sprintf(szMsg, "%s %s",m_strDeviceStats, m_strFrameStats );

	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(0.3F,0.9F,0.7F,1.0F) );


	rc.top = 23;
	rc.bottom = rc.top + 20;

	const D3DXVECTOR3* vcCamPos = m_pCam->GetCamPos();

	sprintf(szMsg, "Camera Pos: %.f %.f %.f",vcCamPos->x, vcCamPos->y, vcCamPos->z );
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, D3DXCOLOR(0.3F,0.9F,0.7F,1.0F) );

	return S_OK;
}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				RECT rc;
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				GetClientRect( hWnd, &rc );
				DrawText( hDC, strMsg, -1, &rc, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}


void*	GetMainDevice()
{
	return g_pApp->m_pd3dDevice;
}
