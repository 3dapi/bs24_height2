// Interface for the CMcQuad class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCQUAD_H_
#define _MCQUAD_H_



class CMcQuad
{
public:
	union
	{
		struct
		{
			// ���
			// ���
			CMcQuad*	m_pRH;
			// ���
			// ���
			CMcQuad*	m_pLH;
			// ���
			// ���
			CMcQuad*	m_pLT;
			// ���
			// ���
			CMcQuad*	m_pRT;

			// Parent
			CMcQuad*	m_pP;
		};

		CMcQuad*	pQ[5];
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev;

	INT					m_iDph;			// Min Level
	INT					m_iLvl;
	bool				m_bEnd;			// Terminated
	INT					m_iTri;			// Triangle Count
	D3DXVECTOR3			m_vcP;			// Position
	INT					m_iBrd;			// breadth

	VtxD				m_pVx[8];

public:
	CMcQuad();
	virtual ~CMcQuad();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	Build(CMcQuad* _pPrn, INT iDepth, INT iX,INT iZ);
	void	BuildMesh();

	void	SetDevice(LPDIRECT3DDEVICE9 pDev){	m_pDev = pDev;	}
	void*	GetDevice()						{	return m_pDev;	}

protected:
	INT		GetDepth(INT iValue);
};

#endif