// Implementation of the CMcQuad class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4244)


#include "_StdAfx.h"

INT			g_iLvlW = 150;
D3DXVECTOR3	g_pPos = -D3DXVECTOR3(300, 0, 200);


CMcQuad::CMcQuad()
:	m_pRH(0)
,	m_pLH(0)
,	m_pLT(0)
,	m_pRT(0)
,	m_pP(0)
,	m_iTri(0)
,	m_bEnd(0)
,	m_vcP(0,0,0)
,	m_iDph(0)
{
	m_pDev = NULL;

	for(INT i=0; i<8; ++i)
		m_pVx[i].d = D3DXCOLOR(0,0.3F,0,1);
}


CMcQuad::~CMcQuad()
{
}


void CMcQuad::Destroy()
{
	if(m_pRH)
		m_pRH->Destroy();

	if(m_pLH)
		m_pLH->Destroy();

	if(m_pLT)
		m_pLT->Destroy();

	if(m_pRT)
		m_pRT->Destroy();

	SAFE_DELETE( m_pRH );
	SAFE_DELETE( m_pLH );
	SAFE_DELETE( m_pLT );
	SAFE_DELETE( m_pRT );
}



INT CMcQuad::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	m_iBrd	= 512;
	m_iDph	= 0;
	Build(NULL, m_iDph, 1, 1);
	BuildMesh();

	return 0;
}



INT CMcQuad::GetDepth(INT iValue)
{
	if(iValue>=g_iLvlW*5)
		return 0;

	if(iValue>=g_iLvlW*4)
		return 2;

	if(iValue>=g_iLvlW*3)
		return 3;

	if(iValue>=g_iLvlW*2)
		return 4;

	if(iValue>=g_iLvlW*1)
		return 5;

	if(iValue>=g_iLvlW*0)
		return 6;

	return 6;
}


void CMcQuad::Build(CMcQuad* _pPrn, INT iDepth, INT iX,INT iZ)
{
	m_pP	= _pPrn;
	if(m_pP)
		m_pDev	= (LPDIRECT3DDEVICE9)m_pP->GetDevice();

	m_iDph	= iDepth;

	++m_iDph;

	m_iBrd	= m_pP? m_pP->m_iBrd>>1 : 512;
	m_vcP	= m_pP? m_pP->m_vcP + D3DXVECTOR3(iX*m_iBrd, 0, iZ*m_iBrd) : m_vcP;

	D3DXVECTOR3	vcD		=  m_vcP - g_pPos;
	INT		iDist	= sqrtl(vcD.x*vcD.x + vcD.z*vcD.z)-m_iBrd*1.41421;

	m_iLvl = GetDepth(iDist);

	if(m_iDph > m_iLvl)
		m_bEnd = true;


	if(!m_bEnd)
	{
		m_pRH = new CMcQuad;
		m_pLH = new CMcQuad;
		m_pLT = new CMcQuad;
		m_pRT = new CMcQuad;

		m_pRH->Build(this, m_iDph,  1, 1);
		m_pLH->Build(this, m_iDph, -1, 1);
		m_pLT->Build(this, m_iDph, -1,-1);
		m_pRT->Build(this, m_iDph,  1,-1);
	}
}




void CMcQuad::BuildMesh()
{
	if(m_bEnd)
	{
		D3DXVECTOR3	vcD;
		INT		iDist;
		INT		iLvl;
		INT		bX=0;
		INT		bZ=0;


		for(int z=-1; z<2; ++z)
		{
			for(int x=-1; x<2; ++x)
			{
				if( 0 != x*z || (x==0 && z==0))
					continue;

				vcD		=  m_vcP - g_pPos + 2*D3DXVECTOR3(m_iBrd * x,0, m_iBrd * z);
				iDist	= sqrtl(vcD.x*vcD.x + vcD.z*vcD.z)-m_iBrd*1.41421;
				iLvl	= GetDepth(iDist);

				if(iLvl>m_iLvl && iLvl>=m_iDph)
				{
					bX |=x;
					bZ |=z;
				}
			}
		}

		if(0 == bX && 0 ==bZ)
		{
			m_iTri = 2;

			m_pVx[ 0].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
		}

		else if(1 ==bX && 1 == bZ)
		{
			m_iTri = 6;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,       0);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3(      0, 0,  m_iBrd);
			m_pVx[ 6].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 7].p = m_pVx[ 1].p;
		}

		else if(0 ==bX && 1 == bZ)
		{
			m_iTri = 5;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3(      0, 0,  m_iBrd);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 6].p = m_pVx[ 1].p;
		}

		else if(-1 ==bX && 1 == bZ)
		{
			m_iTri = 6;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3(      0, 0,  m_iBrd);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 6].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,       0);
			m_pVx[ 7].p = m_pVx[ 1].p;
		}

		else if(-1 ==bX && 0 == bZ)
		{
			m_iTri = 5;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,       0);
			m_pVx[ 6].p = m_pVx[ 1].p;
		}

		else if(-1 ==bX && -1 == bZ)
		{
			m_iTri = 6;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3(      0, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 6].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,       0);
			m_pVx[ 7].p = m_pVx[ 1].p;
		}

		else if( 0 ==bX && -1 == bZ)
		{
			m_iTri = 5;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3(      0, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 6].p = m_pVx[ 1].p;
		}

		else if( 1 ==bX && -1 == bZ)
		{
			m_iTri = 6;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3(      0, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,       0);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 6].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 7].p = m_pVx[ 1].p;
		}

		else if( 1 ==bX &&  0 == bZ)
		{
			m_iTri = 5;

			m_pVx[ 0].p = m_vcP;
			m_pVx[ 1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
			m_pVx[ 2].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
			m_pVx[ 3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,       0);
			m_pVx[ 4].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
			m_pVx[ 5].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
			m_pVx[ 6].p = m_pVx[ 1].p;
		}

	}

	else
	{
		if(m_pRH)
			m_pRH->BuildMesh();

		if(m_pLH)
			m_pLH->BuildMesh();

		if(m_pLT)
			m_pLT->BuildMesh();

		if(m_pRT)
			m_pRT->BuildMesh();
	}
}


void CMcQuad::Render()
{
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);

	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);

	VtxD	pLine[5];
	pLine[0].d = D3DXCOLOR(0, m_iDph/16.F, 1.F, 1.F);
	pLine[1].d = pLine[0].d;
	pLine[2].d = pLine[0].d;
	pLine[3].d = pLine[0].d;

	pLine[0].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0, -m_iBrd);
	pLine[1].p = m_vcP + D3DXVECTOR3(-m_iBrd, 0,  m_iBrd);
	pLine[2].p = m_vcP + D3DXVECTOR3( m_iBrd, 0,  m_iBrd);
	pLine[3].p = m_vcP + D3DXVECTOR3( m_iBrd, 0, -m_iBrd);
	pLine[4] = pLine[0];

	m_pDev->DrawPrimitiveUP(D3DPT_LINESTRIP, 4, pLine, sizeof(VtxD));

	if(pQ[0])
	{
		for(int i=0; i<4; ++i)
			pQ[i]->Render();
	}


	if(m_iTri)
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, m_iTri, m_pVx, sizeof(VtxD));


}



INT	CMcQuad::FrameMove()
{
	return 0;
}