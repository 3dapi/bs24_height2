// Implementation of the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcSplt.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


INT m_IdxLA[][33] =	 					// Texture Index
{
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	1,1,3,3,3,3,0,0,	0,2,2,2,2,1,1,1,	3,1,3,3,1,1,1,1,1,	},

	{0,0,0,1,1,1,1,1,	3,3,3,3,3,3,3,3,	0,1,1,2,0,0,2,1,	2,3,3,2,0,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	3,3,3,3,3,3,3,3,	0,1,1,2,2,3,0,1,	2,1,1,2,0,1,1,1,1,	},
	{0,0,0,1,1,1,1,1,	3,3,3,2,3,3,3,1,	0,0,1,3,3,1,1,1,	1,1,1,2,0,1,1,1,1,	},
	{0,0,0,1,1,1,3,3,	3,3,3,3,3,2,2,0,	0,1,1,1,3,1,1,1,	2,2,2,1,0,1,1,1,1,	},

	{0,0,0,1,1,1,3,3,	3,3,3,3,2,2,2,0,	0,1,1,1,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},
	{0,0,0,3,3,3,3,3,	3,3,2,2,2,2,2,0,	0,2,2,2,3,1,2,2,	2,2,2,2,1,2,2,2,2,	},
	{0,0,0,3,3,3,3,3,	3,3,2,2,2,2,0,0,	0,1,2,0,2,2,2,1,	1,1,2,2,2,1,1,1,1,	},
	{0,0,0,3,3,3,3,3,	3,3,2,2,2,2,2,0,	0,0,2,2,0,2,2,0,	2,0,2,2,1,1,1,1,1,	},

	{0,0,0,3,3,3,3,3,	2,2,2,2,2,2,2,1,	0,0,1,2,0,0,2,1,	2,1,1,2,3,1,1,1,1,	},
	{0,0,0,3,3,3,3,3,	2,2,2,2,2,2,2,0,	0,0,1,2,0,0,0,1,	2,1,3,3,3,1,1,1,1,	},
	{0,0,0,1,1,1,2,2,	2,2,2,2,2,2,1,0,	0,0,1,2,0,1,3,3,	1,0,1,2,1,1,1,1,1,	},
	{0,0,0,1,1,1,2,2,	2,2,2,2,2,1,1,0,	0,0,2,1,0,1,3,3,	2,2,2,1,1,1,1,1,1,	},

	{0,0,0,1,1,1,1,1,	2,2,2,2,2,1,1,0,	0,0,1,3,3,1,1,1,	3,1,3,3,1,2,2,2,2,	},
	{0,0,0,2,2,2,2,2,	2,2,2,2,2,2,2,0,	0,0,2,2,2,2,2,2,	2,2,2,2,2,2,2,2,2,	},
	{0,0,0,2,2,2,2,0,	0,2,2,3,2,2,2,1,	0,0,0,0,2,2,2,1,	1,3,2,3,2,1,1,1,1,	},
	{0,0,0,2,2,2,2,0,	0,3,3,3,3,2,2,0,	2,0,0,2,0,2,2,2,	2,3,3,3,2,1,1,1,1,	},

	{0,0,0,2,2,0,2,0,	0,3,3,3,3,0,0,0,	0,0,1,2,0,0,2,2,	2,3,3,2,2,1,1,1,1,	},
	{0,0,0,2,2,0,0,0,	1,1,1,3,3,0,0,0,	0,0,0,2,2,2,2,2,	2,1,1,2,2,1,1,1,1,	},
	{0,0,0,0,0,0,0,0,	0,0,1,3,3,3,3,0,	0,0,0,3,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},
	{0,0,0,2,2,0,0,0,	0,1,1,1,1,1,1,0,	0,0,0,1,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},

	{0,0,0,2,2,0,0,0,	0,1,1,1,1,1,1,0,	0,0,0,1,3,1,1,1,	1,1,1,1,1,1,1,1,1,	},
	{0,0,0,2,2,2,2,0,	0,2,2,2,2,1,1,0,	0,0,2,2,3,1,2,2,	2,2,2,2,1,1,1,1,1,	},
	{0,0,0,2,2,2,2,0,	0,2,2,2,2,1,1,0,	0,0,2,0,0,2,2,1,	1,1,2,1,1,1,1,1,1,	},
	{0,0,0,0,0,2,2,0,	0,2,2,2,2,2,2,0,	0,0,2,0,0,2,2,1,	2,1,2,2,1,1,1,1,1,	},

	{0,0,0,0,0,0,0,1,	1,1,1,1,1,2,2,0,	0,1,1,0,0,0,2,1,	2,1,2,2,2,1,1,1,1,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
	{0,0,0,0,0,0,0,0,	1,1,1,1,0,0,0,0,	0,1,1,1,1,1,1,1,	1,1,1,1,2,2,2,2,2,	},
};



CLcSplt::CLcSplt()
{
	m_pDev	= NULL;
	m_nVtx	= 0;
	m_pFce	= 0;

	m_pFce	= NULL;
	m_pVtx	= NULL;

	m_iTile	= 0;
	m_fWidth= 0;

	m_nTex	= 0;
	m_pTex	= NULL;

	m_pFVF	= NULL;
	m_pPS	= NULL;
}

CLcSplt::~CLcSplt()
{
	Destroy();
}


INT CLcSplt::Create(PDEV pDev)
{
	m_pDev	= pDev;

	int i, j, n, m;

	int	nTile	= 32;

	m_iTile		= nTile + 1;		// nTile in x, z
	m_fWidth	= 32;				// Width
	m_nTex		= 4;				// Number of Texture Layer

	m_nVtx = m_iTile * m_iTile;
	m_nFce =  nTile * nTile * 2;

	m_pVtx = new VtxDSUV1[m_nVtx];
	m_pFce = new VtxIdx [m_nFce];


	i=0;

	for(m=0; m< nTile/2;++m)
	{
		for(n=0;n<nTile/2;++n)
		{
			WORD s;
			WORD d;
			WORD a;

			WORD f[9];

			s = nTile + 2;

			d=  (nTile+ 1)*2;

			a = m * d + n * 2 + s;

			f[1] = a +nTile+0;	f[2] = a + nTile+1;	f[3] = a +nTile+2;
			f[8] = a - 1;		f[0] = a;			f[4] = a + 1;
			f[7] = a -nTile-2;	f[6] = a - nTile-1;	f[5] = a -nTile-0;

			m_pFce[i+0] = VtxIdx(f[0], f[1], f[2]);
			m_pFce[i+1] = VtxIdx(f[0], f[2], f[3]);
			m_pFce[i+2] = VtxIdx(f[0], f[3], f[4]);
			m_pFce[i+3] = VtxIdx(f[0], f[4], f[5]);
			m_pFce[i+4] = VtxIdx(f[0], f[5], f[6]);
			m_pFce[i+5] = VtxIdx(f[0], f[6], f[7]);
			m_pFce[i+6] = VtxIdx(f[0], f[7], f[8]);
			m_pFce[i+7] = VtxIdx(f[0], f[8], f[1]);

			i +=8;
		}
	}


	for(j=0; j<m_iTile; ++j)
	{
		for(i=0; i<m_iTile; ++i)
		{
			m_pVtx[j*m_iTile+i] = VtxDSUV1(i * m_fWidth, 0, j * m_fWidth, i/5.f, j/5.f, 0xFFFFFF99, 0x0);
		}
	}


	m_pTex = new TexWgt[m_nTex];

	for(i=0; i<m_nTex; ++i)
	{
		char	sFile[MAX_PATH]={0};
		sprintf(sFile, "Texture/Base_%02d.png", i + 1);
		TextureLoad(sFile, m_pTex[i].pTexB);
	}


	char sPxlSh[] =
	/*
		"ps_1_4				\n"

		// sampling 0,1,2,3 stage pixel with texturecoord 0
		"texld r0, t0		\n"     // r0 = sampling(s0, t0)
		"texld r1, t0		\n"     // r1 = sampling(s1, t0)
		"texld r2, t0		\n"     // r2 = sampling(s2, t0)
		"texld r3, t0		\n"     // r3 = sampling(s3, t0)

		// modulate by weight in specular color(r,g,b,a)
		"mul r0, r0, v1.r	\n"		// specular red
		"mul r1, r1, v1.g	\n"		// specular green
		"mul r2, r2, v1.b	\n"		// specular blue
		"mul r3, r3, v1.a	\n"		// specular alpha

		// add for pixel color
		"add r0, r0, r1		\n"		// r0 = r0 + r1
		"add r2, r2, r3		\n"		// r2 = r2 + r3
		"add r1, r0, r2		\n"		// r1 = r0 + r2

		"mul r0, r1, v0		\n"		// r0 = r1 * v0(diffuse)
	*/

		"ps_2_0             \n"

		// declaration diffuse, sampler, texture coordinate
		"dcl v0             \n"     // diffuse color
		"dcl v1.rgba        \n"     // specular color
		"dcl_2d s0          \n"     // sampler 0
		"dcl_2d s1          \n"     // sampler 1
		"dcl_2d s2          \n"     // sampler 2
		"dcl_2d s3          \n"     // sampler 3
		"dcl t0.xy          \n"     // texture coord 0(x,y)

		// sampling 0,1,2,3 stage pixel with texturecoord 0
		"texld r0, t0, s0   \n"     // r0 = sampling(s0, t0)
		"texld r1, t0, s1   \n"     // r1 = sampling(s1, t0)
		"texld r2, t0, s2   \n"     // r2 = sampling(s2, t0)
		"texld r3, t0, s3   \n"     // r3 = sampling(s3, t0)

		// modulate by weight in texture 1 coordinate(x,y,z,w)
		"mul r0, r0, v1.r   \n"     // r0 *= specular .r
		"mul r1, r1, v1.g   \n"     // r1 *= specular .g
		"mul r2, r2, v1.b   \n"     // r2 *= specular .b
		"mul r3, r3, v1.a   \n"     // r3 *= specular .a

		// integrate all pixel color
		"add r0, r0, r1     \n"     // r0 += r0 + r1
		"add r2, r2, r3     \n"     // r2 += r2 + r3
		"add r1, r0, r2     \n"     // r1 += r0 + r2
		"mul r0, r1, v0     \n"     // r0 = r1 * diffuse

		// copy to output register
		"mov oC0, r0        \n"     // out = r0
		;


	if(FAILED(VertexDeclarator()))
		return -1;

	if(FAILED(BuildPixelShader(sPxlSh, strlen(sPxlSh))))
		return -1;


	CalculateMap();

	return 0;
}

void CLcSplt::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pFce	);
	SAFE_DELETE_ARRAY(	m_pVtx	);

	SAFE_DELETE_ARRAY(	m_pTex	);

	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pPS	);
}




INT CLcSplt::FrameMove()
{
	return 0;
}


void CLcSplt::Render()
{
	int i;

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	for(i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU , D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV , D3DTADDRESS_WRAP);
	}

	m_pDev->SetVertexDeclaration(m_pFVF);
	m_pDev->SetPixelShader(m_pPS);

	for(i=0; i<m_nTex; ++i)
		m_pDev->SetTexture(i, m_pTex[i].pTexB);

	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
									, 0
									, m_nVtx
									, m_nFce
									, m_pFce
									, D3DFMT_INDEX16
									, m_pVtx
									, sizeof(CLcSplt::VtxDSUV1)
									);

	for(i=0; i<m_nTex;++i)
		m_pDev->SetTexture(i, NULL);

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
}





////////////////////////////////////////////////////////////////////////////////
void CLcSplt::CalculateMap()
{
	INT		x, z;

	for (z=0; z<m_iTile; ++z)
	{
		for (x=0; x<m_iTile; ++x)
		{
			int nTx = m_IdxLA[z][x];

			D3DXCOLOR tw(0,0,0,0);

			if     (0 == nTx) tw.r = 1.f;
			else if(1 == nTx) tw.g = 1.f;
			else if(2 == nTx) tw.b = 1.f;
			else if(3 == nTx) tw.a = 1.f;

			m_pVtx[m_iTile*z + x].tw = tw;
		}
	}
}


INT CLcSplt::TextureLoad(char* sFileName
						, PDTX& texture
						, DWORD _color
						, D3DXIMAGE_INFO*pSrcInfo
						, DWORD Filter
						, DWORD MipFilter
						, D3DFORMAT d3dFormat)
{
	if (FAILED(D3DXCreateTextureFromFileEx(
		m_pDev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)))
	{
		texture = NULL;
		return -1;
	}

	return 0;
}



INT CLcSplt::VertexDeclarator()
{
	PDVD pFVF = NULL;

	DWORD	dFVF = CLcSplt::VtxDSUV1::FVF;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE];
	memset(vertex_decl, 0, sizeof(vertex_decl));
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);

	if(FAILED(m_pDev->CreateVertexDeclaration(vertex_decl, &pFVF)))
		return -1;

	m_pFVF = pFVF;

	return 0;
}


INT CLcSplt::BuildPixelShader(char* sStrAssem, int iLen)
{
	HRESULT	hr;
	DWORD dwFlags = 0;

#if defined(_DEBUG) || defined(DEBUG)
	dwFlags |= D3DXSHADER_DEBUG;
#endif

	PDPS			pPS	= NULL;
	LPD3DXBUFFER	psh = NULL;

	hr = D3DXAssembleShader(
			sStrAssem
		,	iLen
		,	NULL
		,	NULL
		,	dwFlags
		,	&psh
		,	NULL);


	if (FAILED(hr))
		return NULL;

	hr = m_pDev->CreatePixelShader((DWORD*)psh->GetBufferPointer() , &pPS);

	SAFE_RELEASE(psh);

	if (FAILED(hr))
		return -1;

	m_pPS = pPS;

	return 0;
}