// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_

class CMain : public CD3DApplication
{
public:
	ID3DXFont*			m_pD3DXFont	;											// D3DX font
	CMcInput*			m_pInput	;
	CMcCam*				m_pCam		;

	CMcCircle*			m_pCircle	;
	CMcQuad*			m_pQuad		;


public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();

	virtual HRESULT FrameMove();
	virtual HRESULT Render();

	HRESULT RenderText();

public:
	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
	CMain();
};

extern CMain*	g_pApp;

void*	GetMainDevice();

#endif

