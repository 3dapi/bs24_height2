// Interface for the CMcCircle class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _McCircle_H_
#define _McCircle_H_

class CMcCircle
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;

	VtxD**				m_pRad;

public:
	CMcCircle();
	virtual ~CMcCircle();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif