// Interface for the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcSplt_H_
#define _LcSplt_H_


typedef D3DXVECTOR3							VEC3;
typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPDIRECT3DTEXTURE9					PDTX;


class CLcSplt
{
public:
	struct VtxIdx
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		VtxIdx()						{	a = 0;	  b = 1;	c = 2;		}
		VtxIdx(WORD A, WORD B, WORD C)	{	a = A;	  b = B;	c = C;		}
		VtxIdx(WORD* R)					{	a = R[0]; b = R[1];	c = R[2];	}

		operator WORD* ()				{	return (WORD *) &a;				}
		operator CONST WORD* () const	{	return (CONST WORD *) &a;		}
	};

	struct VtxDUV2
	{
		VEC3	p;
		DWORD		d;
		FLOAT	u1, v1;
		FLOAT	u2, v2;

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX2)	};
	};


	struct TexWgt
	{
		PDTX	pTxB;															// Texture Base
		PDTX	pTxA;															// Texture Alpha

		TexWgt() : pTxB(0), pTxA(0)
		{
		}

		~TexWgt()
		{
			if(pTxB)
			{
				pTxB->Release();
				pTxB=NULL;
			}

			if(pTxA)
			{
				pTxA->Release();
				pTxA=NULL;
			}
		}

	};

protected:
	PDEV		m_pDev;
	INT			m_nVtx;															// Number of Vertices
	INT			m_nFce;															// Number of Indices

	VtxIdx*		m_pFce;
	VtxDUV2*	m_pVtx;

	INT			m_iTile;														// Number of tile for X
	FLOAT		m_fWidth;														// Width of tile for Cell

	INT			m_nTex;															// Layer Number
	TexWgt*	m_pTex;															// Texture Layer


	BOOL		m_bFilter;

public:
	CLcSplt();
	virtual ~CLcSplt();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	SetTextureFilter();

protected:
	void	CalculateMap();
	void	CalculateMapTile(int nTx, PDTX& xpTxA);

	INT		TextureLoad(char* sFileName
						, PDTX& texture
						, DWORD _color=0x00FFFFFF
						, D3DXIMAGE_INFO *pSrcInfo=NULL
						, DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						, D3DFORMAT d3dFormat = D3DFMT_UNKNOWN);
};

#endif
