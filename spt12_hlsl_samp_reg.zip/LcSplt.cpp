// Implementation of the CLcSplt class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4996)

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "LcSplt.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


INT m_IdxLA[][33] =	 					// Texture Index
{
	{4,4,4,3,3,3,1,1,	3,3,3,3,3,3,0,0,	3,5,5,5,2,2,1,1,	6,3,6,3,1,1,3,3,3,	},
	{0,0,4,3,3,3,1,1,	3,3,3,3,3,3,0,0,	3,5,5,5,2,2,1,1,	6,3,6,3,1,1,3,3,3,	},
	{0,4,4,3,3,3,1,1,	3,3,3,3,3,3,0,0,	3,5,5,5,2,2,1,1,	6,3,6,3,1,1,1,3,3,	},
	{0,4,4,3,3,3,1,1,	3,3,3,3,3,3,0,0,	3,5,5,5,2,2,1,1,	6,3,6,3,1,1,1,1,3,	},

	{4,4,0,3,3,3,1,1,	6,6,3,3,3,3,3,3,	3,3,1,2,0,2,2,1,	5,6,6,2,0,1,1,3,3,	},
	{0,4,0,3,3,3,1,1,	6,6,3,3,3,3,3,3,	3,3,1,2,2,2,0,1,	5,3,3,2,0,1,1,1,1,	},
	{0,4,0,3,3,3,1,1,	6,6,3,2,3,3,3,1,	3,3,1,3,3,2,1,1,	3,3,3,2,0,1,1,1,1,	},
	{0,4,0,3,3,3,3,3,	6,6,3,3,3,2,2,0,	3,3,1,1,3,2,1,1,	5,5,5,1,0,1,1,2,2,	},

	{4,0,0,3,3,3,3,3,	6,6,3,3,2,2,2,0,	3,3,1,1,3,1,1,1,	3,3,3,1,1,1,1,2,3,	},
	{4,0,0,6,6,6,3,3,	6,6,2,2,2,2,2,0,	3,5,2,2,3,1,2,2,	5,5,5,2,1,2,2,2,2,	},
	{4,0,0,6,6,6,3,3,	6,6,2,2,2,2,0,0,	3,3,2,0,2,2,2,1,	3,3,5,2,2,1,1,2,3,	},
	{4,0,0,6,6,6,3,3,	6,6,2,2,2,2,2,0,	3,3,2,2,7,7,2,0,	5,3,5,2,1,1,1,1,2,	},

	{0,4,0,6,6,6,3,3,	5,5,2,2,2,2,2,1,	3,3,1,2,7,7,2,1,	5,3,3,2,7,1,1,1,2,	},
	{0,0,0,6,6,6,3,3,	5,5,2,2,2,2,2,0,	3,3,1,2,7,7,7,1,	5,3,6,7,7,1,1,1,4,	},
	{0,3,0,3,3,3,2,2,	5,5,2,2,2,2,1,0,	3,3,1,2,7,7,7,7,	3,7,3,2,2,1,1,1,4,	},
	{3,3,0,3,3,3,2,2,	5,5,2,2,2,1,1,0,	3,3,2,1,7,7,7,7,	5,7,5,2,2,2,2,1,4,	},

	{0,0,0,3,3,3,1,1,	5,5,2,2,2,1,1,0,	3,3,1,3,3,7,7,7,	7,7,1,1,1,2,2,2,2,	},
	{0,0,0,5,5,5,2,2,	5,5,2,2,2,2,2,0,	3,3,2,2,2,2,7,7,	7,7,5,2,2,2,2,2,2,	},
	{0,0,3,5,5,5,2,0,	3,5,2,1,2,2,2,1,	3,3,0,0,2,2,2,7,	7,7,5,1,2,1,1,4,4,	},
	{0,3,3,5,5,5,2,0,	3, 1,1,1,1,2,2,0,	5,3,0,2,0,2,2,2,	5,1,1,1,2,1,1,4,4,	},

	{0,3,3,5,5,3,2,0,	3, 1,1,1,1,0,0,0,	3,3,1,2,0,0,2,2,	5,1,1,2,2,1,1,4,1,	},
	{0,3,3,5,5,3,0,0,	3,3,1,1,1,0,0,0,	3,3,0,1,1,1,2,2,	5,3,3,2,2,1,1,4,1,	},
	{2,2,2,3,3,3,0,0,	3,3,1,1,1,1,1,0,	3,3,0,1,1,1,1,1,	3,3,3,1,2,2,1,1,1,	},
	{2,2,2,5,5,3,0,0,	3,3,1,1,1,1,1,0,	3,3,0,1,1,1,1,1,	3,3,3,1,2,2,1,1,1,	},

	{2,2,2,5,5,3,0,0,	3,3,1,1,1,1,1,0,	3,3,0,1,1,1,1,1,	3,3,3,1,1,2,2,1,1,	},
	{0,0,2,5,5,5,2,0,	3,5,2,2,2,1,1,0,	3,3,2,2,1,1,2,2,	5,5,5,2,1,2,2,1,1,	},
	{0,0,2,5,5,5,2,0,	3,5,2,2,2,1,1,0,	3,3,2,0,0,2,2,1,	3,3,5,1,1,1,1,1,1,	},
	{0,2,2,3,3,5,2,0,	3,5,2,2,2,2,2,0,	7,7,2,5,5,2,2,1,	5,3,5,2,1,1,1,1,1,	},

	{0,2,0,3,3,3,0,1,	3,3,1,1,4,5,5,3,	3,6,6,3,3,0,2,4,	5,1,5,2,2,1,1,1,1,	},
	{0,2,0,3,3,3,0,0,	3,3,1,1,3,3,3,3,	3,6,6,6,6,4,4,4,	5,1,3,1,2,2,2,2,2,	},
	{0,0,2,3,3,3,0,0,	3,3,1,1,3,3,3,3,	3,6,6,6,6,4,4,4,	5,1,3,1,2,2,2,2,2,	},
	{0,0,2,3,3,3,0,0,	3,3,1,1,3,3,3,3,	3,6,6,6,6,4,4,4,	5,5,3,1,2,2,2,2,2,	},
	{0,0,0,3,3,3,0,0,	3,3,1,1,3,3,3,3,	3,6,6,6,6,1,1,1,	5,5,3,1,2,2,2,2,2,	},
};



CLcSplt::CLcSplt()
{
	m_pDev	= NULL;
	m_nVtx	= 0;
	m_pFce	= 0;

	m_pFce	= NULL;
	m_pVtx	= NULL;

	m_iTile	= 0;
	m_fWidth= 0;

	m_nTex	= 0;
	m_pTex	= NULL;

	m_pFVF	= NULL;
	m_pEffct= NULL;
	m_hdTech= NULL;
}

CLcSplt::~CLcSplt()
{
	Destroy();
}


INT CLcSplt::Create(PDEV pDev)
{
	m_pDev	= pDev;

	int i, j, n, m;

	int	nTile	= 32;

	m_iTile		= nTile + 1;		// nTile in x, z
	m_fWidth	= 32;				// Width
	m_nTex		= 8;				// Number of Texture Layer

	m_nVtx = m_iTile * m_iTile;
	m_nFce =  nTile * nTile * 2;

	m_pVtx = new VtxDUV1TW[m_nVtx];
	m_pFce = new VtxIdx [m_nFce];


	i=0;
	for(m=0; m< nTile/2; ++m)
	{
		for(n=0;n<nTile/2; ++n)
		{
			WORD s;
			WORD d;
			WORD a;

			WORD f[9];

			s = nTile + 2;

			d=  (nTile+ 1)*2;

			a = m * d + n * 2 + s;

			f[1] = a +nTile+0;	f[2] = a + nTile+1;	f[3] = a +nTile+2;
			f[8] = a - 1;		f[0] = a;			f[4] = a + 1;
			f[7] = a -nTile-2;	f[6] = a - nTile-1;	f[5] = a -nTile-0;

			m_pFce[i+0] = VtxIdx(f[0], f[1], f[2]);
			m_pFce[i+1] = VtxIdx(f[0], f[2], f[3]);
			m_pFce[i+2] = VtxIdx(f[0], f[3], f[4]);
			m_pFce[i+3] = VtxIdx(f[0], f[4], f[5]);
			m_pFce[i+4] = VtxIdx(f[0], f[5], f[6]);
			m_pFce[i+5] = VtxIdx(f[0], f[6], f[7]);
			m_pFce[i+6] = VtxIdx(f[0], f[7], f[8]);
			m_pFce[i+7] = VtxIdx(f[0], f[8], f[1]);

			i +=8;
		}
	}

	for(j=0; j<m_iTile; ++j)
	{
		for(i=0; i<m_iTile; ++i)
		{
			m_pVtx[j*m_iTile+i] = CLcSplt::VtxDUV1TW(i * m_fWidth, 0, j * m_fWidth, i/5.f, j/5.f);
		}
	}


	m_pTex = new TexWgt[m_nTex];

	for(i=0; i<m_nTex; ++i)
	{
		char	sFile[MAX_PATH]={0};
		sprintf(sFile, "Texture/Base_%02d.png", i + 1);
		TextureLoad(sFile, m_pTex[i].pTexB);
	}


	if(FAILED(VertexDeclarator()))
		return -1;

	if(FAILED(BuildHlsl()))
		return -1;


	CalculateMap();

	return 0;
}


void CLcSplt::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pFce	);
	SAFE_DELETE_ARRAY(	m_pVtx	);

	SAFE_DELETE_ARRAY(	m_pTex	);

	SAFE_RELEASE(	m_pFVF		);
	SAFE_RELEASE(	m_pEffct	);		// ���̴�
}



INT CLcSplt::Restore()
{
	m_pEffct->OnResetDevice();

	return 0;
}


void CLcSplt::Invalidate()
{
	m_pEffct->OnLostDevice();
}



INT CLcSplt::FrameMove()
{
	return 0;
}


void CLcSplt::Render()
{
	INT	i =0;

	for(i=0; i<m_nTex;++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER,   D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER,   D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER,   D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU ,   D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV ,   D3DTADDRESS_WRAP);

		m_pDev->SetTexture(i, m_pTex[i].pTexB);		// diffuse map
	}


	m_pDev->SetVertexDeclaration(m_pFVF);
	m_pEffct->SetTechnique(m_hdTech);

	m_pEffct->Begin(NULL, 0);
	m_pEffct->BeginPass(0);

	m_pDev->DrawIndexedPrimitiveUP(
					D3DPT_TRIANGLELIST
					, 0
					, m_nVtx
					, m_nFce
					, m_pFce
					, D3DFMT_INDEX16
					, m_pVtx
					, sizeof(CLcSplt::VtxDUV1TW)
					);

	m_pEffct->EndPass();
	m_pEffct->End();

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	for(i=0; i<m_nTex;++i)
		m_pDev->SetTexture(i, NULL);

}



////////////////////////////////////////////////////////////////////////////////
void CLcSplt::CalculateMap()
{
	INT		x, z;

	for (z=0; z<m_iTile; ++z)
	{
		for (x=0; x<m_iTile; ++x)
		{
			int nTx = m_IdxLA[z][x];

			//			nTx = rand()%16;

			VEC4 tw0(0,0,0,0);
			VEC4 tw1(0,0,0,0);

			if     (0 == nTx) tw0.x = 1.f;
			else if(1 == nTx) tw0.y = 1.f;
			else if(2 == nTx) tw0.z = 1.f;
			else if(3 == nTx) tw0.w = 1.f;
			else if(4 == nTx) tw1.x = 1.f;
			else if(5 == nTx) tw1.y = 1.f;
			else if(6 == nTx) tw1.z = 1.f;
			else if(7 == nTx) tw1.w = 1.f;

			m_pVtx[m_iTile*z + x].tw0 = tw0;
			m_pVtx[m_iTile*z + x].tw1 = tw1;

		}// for
	}// for
}



INT CLcSplt::TextureLoad(char* sFileName
						 , PDTX& texture
						 , DWORD _color
						 , D3DXIMAGE_INFO*pSrcInfo
						 , DWORD Filter
						 , DWORD MipFilter
						 , D3DFORMAT d3dFormat)
{
	if (FAILED(D3DXCreateTextureFromFileEx(
		m_pDev
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)))
	{
		texture = NULL;
		return -1;
	}

	return 0;
}



INT CLcSplt::VertexDeclarator()
{
	PDVD pFVF = NULL;

	DWORD	dFVF = CLcSplt::VtxDUV1TW::FVF;

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE];
	memset(vertex_decl, 0, sizeof(vertex_decl));
	D3DXDeclaratorFromFVF(dFVF, vertex_decl);

	if(FAILED(m_pDev->CreateVertexDeclaration(vertex_decl, &pFVF)))
		return -1;

	m_pFVF = pFVF;

	return 0;
}


INT CLcSplt::BuildHlsl()
{
	HRESULT	hr;
	DWORD dwFlags = 0;

#if defined(_DEBUG) || defined(DEBUG)
	dwFlags |= D3DXSHADER_DEBUG;
#endif

	LPD3DXBUFFER	pErr = NULL;


	hr = D3DXCreateEffectFromFile(
		m_pDev
		, "Data/hlsl.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEffct
		, &pErr);

	if(FAILED(hr))
	{

		MessageBox(GetActiveWindow(), (char*)pErr->GetBufferPointer(), "ERROR", MB_OK);
		SAFE_RELEASE(pErr);
		return -1;
	}

	m_hdTech	= m_pEffct->GetTechniqueByName("TShader");

	if(NULL == m_hdTech)
		return -1;

	return 0;
}

